<?php 
echo " salut arta comment cava ";
echo "cherif cava je vais bien ";
echo " arta ";
?>